// Listen for requests from the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getCookies") {
    const url = message.url;

    chrome.cookies.getAll({ url: url }, (cookies) => {
      if (!cookies.length) {
        sendResponse({ success: false, cookies: [] });
      } else {
        const cookieString = cookies.map(c => `${c.name}=${c.value}`).join("; ");
        sendResponse({ success: true, cookies: cookieString });
      }
    });

    // Return true to indicate we will send the response asynchronously
    return true;
  }
});
