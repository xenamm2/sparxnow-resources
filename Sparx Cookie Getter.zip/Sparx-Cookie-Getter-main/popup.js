document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("copyCookiesBtn");

  btn.addEventListener("click", () => {
    // Get active tab URL
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabUrl = tabs[0].url;

      // Send message to background to get cookies
      chrome.runtime.sendMessage(
        { action: "getCookies", url: tabUrl },
        (response) => {
          if (!response.success) {
            alert("No cookies found for this site!");
            return;
          }

          // Copy cookies to clipboard
          navigator.clipboard.writeText(response.cookies)
            .then(() => alert("Cookies copied to clipboard!"))
            .catch(err => console.error("Clipboard error: ", err));
        }
      );
    });
  });
});
